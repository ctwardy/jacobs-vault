#!/bin/bash
export FLASK_APP=hittestservice.py
python -m flask run

