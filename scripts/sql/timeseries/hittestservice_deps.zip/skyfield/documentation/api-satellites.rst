
==================================
 API Reference — Earth Satellites
==================================

.. currentmodule:: skyfield.sgp4lib

See :doc:`earth-satellites` for an introduction to downloading Earth
satellite data and computing their positions with Skyfield.

.. autoclass:: EarthSatellite
   :members:
